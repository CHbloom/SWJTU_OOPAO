import gym
from gym import spaces
import numpy as np
import time
from OOPAO.Atmosphere import Atmosphere
from OOPAO.DeformableMirror import DeformableMirror
from OOPAO.Source import Source
from OOPAO.Telescope import Telescope
from OOPAO.ShackHartmann import ShackHartmann
from OOPAO.calibration.ao_calibration import ao_calibration
from tutorials.scao_system.myAoSystem.Imager import Imager
import matplotlib.pyplot as plt
class AOEnv(gym.Env):
    def __init__(self):
        super(AOEnv, self).__init__()

        # 初始化望远镜、光源、大气、变形镜、波前传感器和科学相机
        self.tel = Telescope(resolution=120, diameter=8, samplingTime=1/1000, centralObstruction=0)
        self.ngs = Source(optBand='I', magnitude=8)
        self.ngs * self.tel
        self.atm = Atmosphere(telescope=self.tel, r0=0.15, L0=30, windSpeed=[10, 12, 11, 15, 20],
                              fractionalR0=[0.45, 0.1, 0.1, 0.25, 0.1], windDirection=[0, 72, 144, 216, 288],
                              altitude=[0, 1000, 5000, 10000, 12000])
        self.atm.initializeAtmosphere(telescope=self.tel)
        self.dm = DeformableMirror(telescope=self.tel, nSubap=20, mechCoupling=0.45)
        self.wfs = ShackHartmann(nSubap=20, telescope=self.tel, lightRatio=0.3, is_geometric=False, threshold_cog=0.01)
        self.camH = Imager(telescope=self.tel, nPix=128, fieldStopSize=10, wavelength=self.ngs.wavelength)

        # 定义动作空间和状态空间
        self.action_space = spaces.Box(
            low=np.array([0.1, 500, 0.1, 10, 10]),  # 最小增益、采样频率、模式数
            high=np.array([1.0, 2000, 1.0, 100, 100]),  # 最大增益、采样频率、模式数
            dtype=np.float32
        )

        self.observation_space = spaces.Box(
            low=0, high=1, shape=(self.wfs.nSignal + self.camH.nPix ** 2 + 3,), dtype=np.float32
        )

        # 初始化参数
        self.param = {'nLoop': 20}
        self.gainCL = 0.6
        self.wfs.cam.photonNoise = True
        self.SR = np.zeros(self.param['nLoop'])
        self.total = np.zeros(self.param['nLoop'])
        self.residual = np.zeros(self.param['nLoop'])
        self.wfsSignal = np.zeros(self.wfs.nSignal)

    def reset(self):
        """重置环境到初始状态"""
        self.dm.coefs = 0
        self.SR = np.zeros(self.param['nLoop'])
        self.total = np.zeros(self.param['nLoop'])
        self.residual = np.zeros(self.param['nLoop'])
        self.wfsSignal = np.zeros(self.wfs.nSignal)
        self.atm.initializeAtmosphere(telescope=self.tel)
        return self._get_state()

    def step(self, action):
        """
        执行动作并返回新的状态、奖励和是否结束。

        参数：
        - action: 动作向量

        返回：
        - state: 新状态
        - reward: 奖励
        - done: 是否结束
        - info: 附加信息
        """
        # 更新动作参数
        self.gainCL = action[0]  # 波前传感器增益
        self.wfs.cam.samplingFreq = action[1]  # 波前传感器采样频率
        self.camH.gain = action[2]  # 成像相机增益
        self.camH.frameRate = action[3]  # 成像相机帧频
        self.nModes = int(action[4])  # 复原模式数

        # 更新大气湍流相位屏
        self.atm.update()

        # 记录总的波前误差
        self.total[self.current_step] = np.std(self.tel.OPD[np.where(self.tel.pupil > 0)]) * 1e9

        # 光波传播：自然引导星 -> 望远镜 -> 变形镜 -> 波前传感器
        self.tel * self.dm * self.wfs

        # 更新变形镜控制信号
        self.dm.coefs = self.dm.coefs - self.gainCL * self.M2C_CL @ self.calib_CL.M @ self.wfsSignal

        # 更新波前传感器信号
        self.wfsSignal = self.wfs.signal

        # 光波传播：自然引导星 -> 望远镜 -> 变形镜 -> 科学相机
        self.ngs * self.tel * self.dm * self.camH

        # 计算斯特列尔比（基于科学相机的PSF）
        self.SR[self.current_step] = self.camH.strehl

        # 记录残余波前误差
        self.residual[self.current_step] = np.std(self.tel.OPD[np.where(self.tel.pupil > 0)]) * 1e9

        # 计算奖励
        reward = self.SR[self.current_step] - 0.1 * self.residual[self.current_step]

        # 更新步数
        self.current_step += 1

        # 检查是否结束
        done = self.current_step >= self.param['nLoop']

        # 返回新状态、奖励和是否结束
        return self._get_state(), reward, done, {}

    def _get_state(self):
        """获取当前状态"""
        state = np.concatenate([
            self.wfsSignal.flatten(),  # 波前传感器斜率
            self.camH.frame.flatten(),  # 远场图像
            np.array([self.gainCL, self.wfs.cam.samplingFreq, self.camH.gain])  # 其他状态
        ])
        return state

    def render(self, mode='human'):
        """显示当前状态"""
        if mode == 'human':
            plt.figure()
            plt.imshow(self.camH.frame, cmap='gray')
            plt.title('Science Camera Frame')
            plt.colorbar(label='Intensity')
            plt.show()